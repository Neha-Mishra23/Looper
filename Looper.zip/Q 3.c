//Q.3 Digit Addition
//Develop a Program to find the sum of a number's first and last digits.
//Example:
//Input: Enter any number: 384
//Output: The sum of the first and the last digit: 7

#include<stdio.h>
#include<conio.h>

main()
{
	int num,firstdigit,lastdigit,sum;
	
	printf("enter any number:");
	scanf("%d",&num);
	
	lastdigit=num%10;
	
	while(num >=10)
	{
		num /=10;
	}
	
	firstdigit=num;
	
	sum=firstdigit + lastdigit ;
	printf("sum is %d",sum);
}
