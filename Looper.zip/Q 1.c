//Q.1 Alphabet Skipper
//Develop a program that prints all alphabets from �a� to �z� by skipping 3 alphabets using a
//do-while loop.
//Example:
//Output: a, e, i, m, q, u, y

#include<stdio.h>
#include<conio.h>

main()
{
	char alphabet='a';
	
	do{
		printf("%c ",alphabet);
		alphabet+=4;
	}while(alphabet<='z');
	
	
	
}
